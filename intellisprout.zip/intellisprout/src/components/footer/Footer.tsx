
const Footer = () => {
  return (
    <div className="bg-primary p-4">
      <div>
        <p className="text-primary-foreground">IntelliSprout © 2024 - All Rights Reserved</p>
      </div>
    </div>
  )
}

export default Footer