import { Link } from "react-router-dom"
import { motion } from "framer-motion"
import { useState } from "react"
import { ModeToggle } from "../ModeToggle"
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar"

const Header = () => {
 
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeLink, setActiveLink] = useState("/")
  const userLog = false;
  const navItems = [
    {
      name: "Home",
      path: "/"
    },
    {
      name: "About",
      path: "/about"
    },
    {
      name: "Courses",
      path: "/courses"
    },
    {
      name: "FAQ",
      path: "/faq"
    }
  ]
  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  }

  
  return (
    <header className="bg-background flex items-center sticky z-50 h-16 px-2 top-0 left-0 backdrop-blur-sm">
      <nav className="container h-16 flex justify-between mx-auto items-center">
        <div className="md:hidden flex items-center justify-start w-[25vw]">
          <div
            onClick={toggleMenu}
            className="flex duration-300 flex-col justify-around relative z-10 w-8 h-8 cursor-pointer"
          >
            <motion.div
              animate={isMenuOpen ? { rotate: 45, y: 10 } : { rotate: 0, y: 0 }}
              className="w-full h-[3px] bg-black dark:bg-white rounded"
            />
            <motion.div
              animate={isMenuOpen ? { opacity: 0 } : { opacity: 1 }}
              className="w-3/5 h-[3px] bg-black dark:bg-white rounded"
            />
            <motion.div
              animate={
                isMenuOpen ? { rotate: -45, y: -11 } : { rotate: 0, y: 0 }
              }
              className="w-full h-[3px] bg-black dark:bg-white rounded"
            />
          </div>
        </div>
        <div className="text-lg flex w-[25vw] items-center justify-center md:justify-start font-bold">
          <Link to="/" className="flex items-baseline">
            <span className="text-2xl text-primary">Intelli</span>
            <span className="font-bold text-primary text-2xl">Sprout</span>
          </Link>
        </div>
        <div
          className={`flex md:px-12 md:h-16 flex-col transition-all duration-300 fixed left-0 top-0 h-screen bg-secondary items-center justify-center overflow-hidden md:relative md:bg-transparent md:flex-row ${isMenuOpen ? "w-[70vw] md:w-auto" : "w-[0vw] md:w-auto"
            }`}
        >
          {navItems.map((item) => (
            <Link onClick={toggleMenu} key={item.path} to={item.path}>
              <div
                className={`relative mx-2 px-2 py-2 ${activeLink === item.path
                  ? "text-white"
                  : "hover:text-primary"
                  } font-medium`}
                onClick={() => setActiveLink(item.path)}
              >
                <p className="relative z-20">{item.name}</p>
                {activeLink === item.path && (
                  <motion.div
                    layoutId="underline"
                    className={`absolute z-0 bottom-1 right-0 h-[28px] bg-primary rounded-lg w-full`}
                    transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  />
                )}
              </div>
            </Link>
          ))}
        </div>
        <div className="w-[25vw] flex gap-2 items-center justify-end">
          {userLog ? (
            <Link to="/account">
              <Avatar className="w-8 h-8">
                <AvatarImage className="object-contain" src="" />
                <AvatarFallback className="bg-primary text-white">IS</AvatarFallback>
              </Avatar>
            </Link>
          ) : (
            <div className="flex gap-2">
            <Link to="/login">
              <p className="font-medium rounded-full text-primary px-3 pt-1 pb-2 hover:text-primary-foreground hover:bg-primary">
                Login
              </p>
            </Link>
            <Link to="/signup">
              <p className="font-medium rounded-full text-primary px-3 pt-1 pb-2 hover:text-primary-foreground hover:bg-primary">
                Signup
              </p>
            </Link>
            </div>
          )}
        </div>
      </nav>
    </header>
  )
}

export default Header