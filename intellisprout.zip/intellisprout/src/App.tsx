import './App.css'
import { Outlet, ScrollRestoration } from 'react-router-dom'
import Header from './components/header/Header'
import Footer from './components/footer/Footer'
import { ThemeProvider } from "@/components/ThemeProvider"

function App() {
  return (
    <ThemeProvider defaultTheme="system" storageKey="vite-ui-theme">
      <Header />
      <ScrollRestoration />
      <Outlet />
      <Footer />
    </ThemeProvider>
  )
}

export default App
