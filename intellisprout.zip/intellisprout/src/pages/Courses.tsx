import React from 'react'

type Props = {}

const Courses = (props: Props) => {
  return (
    <div>Courses</div>
  )
}

export default Courses