"use client";

import React, { FC } from "react";
import { BiSearch } from "react-icons/bi";
import { Link } from "react-router-dom";

type Props = {};

const Home: FC<Props> = () => {
  return (
    <div className="relative w-full flex flex-col items-center">
      <div className="absolute top-[100px] h-[50vh] w-[50vh] rounded-full bg-[linear-gradient(147.92deg,hsla(120,76%,53%,0.456)_10.41%,hsla(0,0%,100%,0)_80.25%)]"></div>
      <div className="flex flex-col items-center justify-center w-full h-screen pt-[70px] z-10">
        <img
          src="https://www.freeiconspng.com/uploads/education-png-10.png"
          alt="Education Icon"
          className="object-contain h-[250px] mb-4"
        />
        <h2 className="text-[#000000c7] text-[30px] md:text-[70px] font-semibold font-Josefin py-2 leading-tight text-center">
          Intellisprout
        </h2>
        <p className="text-[#000000c7] font-Josefin font-semibold text-[18px] md:w-[55%] text-center mb-8">
          Your gateway to a world of knowledge and skills.
        </p>
        <div className="relative w-[90%] md:w-[60%] h-[50px] mb-8">
          <input
            type="search"
            placeholder="Search Courses"
            className="bg-transparent border dark:border-none dark:bg-[#575757] dark:placeholder:text-[#ffffffdd] rounded-l-[5px] p-2 w-full h-full outline-none text-[#0000004e] dark:text-[#ffffffe5] text-[20px] font-medium"
          />
          <div className="absolute flex items-center justify-center w-[50px] cursor-pointer h-full right-0 top-0 bg-primary rounded-r-[5px] hover:bg-primary/80 transition duration-200">
            <BiSearch className="text-white" size={30} />
          </div>
        </div>
        <div className="flex items-center justify-center mb-8">
          <img
            src="https://edmy-react.hibootstrap.com/images/banner/client-3.jpg"
            alt="Client 1"
            className="rounded-full w-[50px] h-[50px] border-2 border-white"
          />
          <img
            src="https://edmy-react.hibootstrap.com/images/banner/client-1.jpg"
            alt="Client 2"
            className="rounded-full w-[50px] h-[50px] border-2 border-white -ml-2"
          />
          <img
            src="https://edmy-react.hibootstrap.com/images/banner/client-2.jpg"
            alt="Client 3"
            className="rounded-full w-[50px] h-[50px] border-2 border-white -ml-2"
          />
        </div>
        <p className="font-Josefin text-[#000000b3] text-[18px] font-semibold text-center">
          500k+ People already trusted us.{" "}
          <Link to="/courses" className="text-crimson hover:text-[#46e256] transition duration-200">
            View Courses
          </Link>
        </p>
      </div>
    </div>
  );
}

export default Home;