import React from 'react'

type Props = {}

const Faq = (props: Props) => {
  return (
    <div>Faq</div>
  )
}

export default Faq