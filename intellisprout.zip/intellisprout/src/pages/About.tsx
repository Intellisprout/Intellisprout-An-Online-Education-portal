"use client";

import React from "react";
import { Link } from "react-router-dom";

const About = () => {
  return (
    <section className="flex flex-col items-center justify-center w-full h-screen bg-gray-100">
      <div className="max-w-4xl mx-auto p-6">
        <h1 className="text-4xl md:text-6xl font-bold text-center text-[#000000c7] mb-4">
          About Us
        </h1>
        <p className="text-lg md:text-xl text-center text-[#000000b3] mb-8">
          At Intellisprout, we are dedicated to providing high-quality education and resources to help you grow and succeed in your learning journey.
        </p>
        <h2 className="text-3xl md:text-5xl font-semibold text-center text-[#000000c7] mb-4">
          Our Mission
        </h2>
        <p className="text-lg md:text-xl text-center text-[#000000b3] mb-8">
          Our mission is to empower individuals through accessible and affordable education, fostering a community of lifelong learners.
        </p>
        <h2 className="text-3xl md:text-5xl font-semibold text-center text-[#000000c7] mb-4">
          Meet Our Team
        </h2>
        <div className="flex flex-wrap justify-center mb-8">
          <div className="flex flex-col items-center m-4">
            <img
              src="https://via.placeholder.com/150"
              alt="Team Member 1"
              className="rounded-full w-32 h-32 mb-2 border-2 border-white"
            />
            <h3 className="font-semibold text-lg">Mohd. Asad</h3>
            <p className="text-sm text-[#000000b3]">Designer</p>
          </div>
          <div className="flex flex-col items-center m-4">
            <img
              src="https://via.placeholder.com/150"
              alt="Team Member 2"
              className="rounded-full w-32 h-32 mb-2 border-2 border-white"
            />
            <h3 className="font-semibold text-lg">Neeraj Sharma</h3>
            <p className="text-sm text-[#000000b3]">Frontend developer</p>
          </div>
          <div className="flex flex-col items-center m-4">
            <img
              src="https://via.placeholder.com/150"
              alt="Team Member 3"
              className="rounded-full w-32 h-32 mb-2 border-2 border-white"
            />
            <h3 className="font-semibold text-lg">Harshit Sharma</h3>
            <p className="text-sm text-[#000000b3]">Firebase expert</p>

          </div>
        </div>
        <Link to="/" className="mt-4 text-primary hover:text-primary/80 transition duration-200">
          Back to Home
        </Link>
      </div>
    </section>
  );
}

export default About;