// src/Login.tsx
import { Input } from '@/components/ui/input';
import React, { useState } from 'react';
import { FaGoogle } from 'react-icons/fa6';

const Signup: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSignup = async (e: React.FormEvent) => {
   
  };

  const handleGoogleLogin = async () => {
    
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100">
      <form onSubmit={handleSignup} className="bg-white p-6 rounded shadow-md w-full max-w-lg">
        <h2 className="text-2xl mb-4">Login</h2>
        <Input
          type="name"
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          className="p-2 mb-4"
          required
        />
        <Input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className="p-2 mb-4"
          required
        />
        <Input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="border p-2 mb-4"
          required
        />
        <div className='flex gap-2 items-center'>

        <button type="submit" className="bg-primary text-white p-2 rounded w-full">Login</button>
        or
        <button type="button" onClick={handleGoogleLogin} className="bg-red-500 text-white p-2 rounded w-full flex items-center justify-center gap-2">Signup with <FaGoogle/></button>
        </div>
      </form>
    </div>
  );
};

export default Signup;